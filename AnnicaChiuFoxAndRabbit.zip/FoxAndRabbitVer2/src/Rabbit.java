public class Rabbit extends Animal {

    private boolean haveSeenFox = false;
    private boolean canSeeFoxNow = false;
    private int directionToFox;
    private int currentDirection;
    private int lastDirection;

    private int closestWallDirection = 0;
    private int numSeenFox = 0;


    public Rabbit(Model model, int row, int column) {
        super(model, row, column);
        currentDirection = Model.STAY;
    }

    int decideMove() {
        canSeeFoxNow = false;
        // looking around for things
        for (int i = Model.MIN_DIRECTION; i <= Model.MAX_DIRECTION; i++) {
            // find direction to fox
            if (look(i) == Model.FOX) {
                canSeeFoxNow = haveSeenFox = true;
                directionToFox = i;
            }
            // find the closest wall
            if (look(i) == Model.EDGE && distance(i) < distance(closestWallDirection)) {
                closestWallDirection = i;
            }
            // count the number of times the rabbit sees the fox consecutively
            if (canSeeFoxNow) {
                numSeenFox++;
            }
            // reset the number of times the rabbit sees the fox
            if (!canSeeFoxNow) {
                numSeenFox = 0;
            }
        }
        /*
         * IF RABBIT CAN'T SEE THE FOX
         */
        if (!canSeeFoxNow) {
            // if the rabbit is too close to the closest wall,
            // move away, to prevent getting cornered
            if (distance(closestWallDirection) < 4) {
                if (canMove(Model.turn(closestWallDirection, 4))) {
                    return Model.turn(closestWallDirection, 4);
                }
            }
            // otherwise, stay in the same place
            return Model.STAY;
        }

        /*
         IF RABBIT CAN SEE THE FOX
         */
        if (canSeeFoxNow) {
            /*
             * get out of the line of sight
             * loop through the best turns to make
             * 4 is the worst, 3 is the best, so the loop will end at the best option
             */
            int bestDirectionNums[] = {4, -2, 2, -1, 1, -3, 3};
            for (int i = 0; i < bestDirectionNums.length; i++) {
                if (canMove(Model.turn(directionToFox, bestDirectionNums[i]))) {
                    currentDirection = Model.turn(directionToFox, bestDirectionNums[i]);
                }
            }
            /* if the rabbit keeps seeing the fox (stop from going in the same direction)
             * if the currentDirection is the same as the one before and the rabbit has seen the fox before (aka they are going in the same direction)
             */
            if (currentDirection == lastDirection && numSeenFox >= 2) {
                // the best turn to make in descending order
                int bestDirectionNumsAfterRepeat[] = {2, 4, 3, 1};
                for (int i = 0; i < bestDirectionNumsAfterRepeat.length; i++) {
                    // if rabbit can move in that direction and the direction is not going to the fox
                    if (canMove(Model.turn(currentDirection, bestDirectionNumsAfterRepeat[i])) &&
                            directionToFox != Model.turn(currentDirection, bestDirectionNumsAfterRepeat[i])) {
                        currentDirection = Model.turn(currentDirection, bestDirectionNumsAfterRepeat[i]);
                    }
                }
            }
            // update the lastDirection
            lastDirection = currentDirection;
        }
        return currentDirection;

    }
}
